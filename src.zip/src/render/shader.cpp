#include "rasterizer_renderer.h"
#include "../utils/math.hpp"
#include <cstdio>

#ifdef _WIN32
    #undef min
    #undef max
#endif

using Eigen::Vector3f;
using Eigen::Vector4f;

// vertex shader
VertexShaderPayload vertex_shader(const VertexShaderPayload& payload)
{
    VertexShaderPayload output_payload = payload;
    // --- 获取 Uniforms ---
    const Eigen::Matrix4f& MVP = Uniforms::MVP;          // Projection * View * Model
    const Eigen::Matrix4f& G   = Uniforms::inv_trans_M;  // 法线变换矩阵 (M^-1)^T
    Eigen::Vector4f pos_model = payload.world_position;
    // Vertex position transformation
    Eigen::Vector4f pos_clip = MVP * pos_model;
    output_payload.viewport_position = pos_clip; // 存储齐次剪裁坐标 (等待光栅化阶段进行透视除法和视口变换)
    Eigen::Matrix4f M = (G.transpose()).inverse();
    Eigen::Vector4f pos_world_homo = M * pos_model;
    output_payload.world_position = pos_world_homo;
    // Viewport transformation
    Eigen::Vector4f normal_model_homo(payload.normal.x(), payload.normal.y(), payload.normal.z(), 0.0f);
    Eigen::Vector4f normal_transformed_homo = G * normal_model_homo;
    output_payload.normal = normal_transformed_homo.head<3>().normalized();
    // Vertex normal transformation

    return output_payload;
}

Vector3f phong_fragment_shader(
    const FragmentShaderPayload& payload, const GL::Material& material,
    const std::list<Light>& lights, const Camera& camera
)
{
    // these lines below are just for compiling and can be deleted
    (void)payload;
    (void)material;
    (void)lights;
    (void)camera;
    // these lines above are just for compiling and can be deleted

    Vector3f result = {0, 0, 0};

    // ka,kd,ks can be got from material.ambient,material.diffuse,material.specular

    // set ambient light intensity

    // Light Direction

    // View Direction

    // Half Vector

    // Light Attenuation

    // Ambient

    // Diffuse

    // Specular

    // set rendering result max threshold to 255
    return result * 255.f;
}
